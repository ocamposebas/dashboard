Phase One Operations Bridge
===========================

Install this small companion plugin beside Phase One COA Manager 2.7.1 and
Phase One Labz Points & Rewards 2.0.0. It adds a secure bridge used by the
local Operations Suite to edit existing COA records and read the real customer
points balance, store credit, reward audit history and redemption history.
It accepts only an existing WooCommerce API key with write or read/write
permission whose owner can edit WordPress posts.

The bridge does not expose credentials to the browser. The local Node server
sends them server-to-server over HTTPS.

Version 1.1.0 adds the customer rewards endpoint. It exposes only operational
reward fields and never returns passwords, authentication tokens or payment
credentials.

Version 1.2.0 adds governed Site Controls publishing. It delegates promotion
validation, temporary sale prices, countdown behavior and maintenance state to
the active Phase One Site Controls plugin, preserving existing variant and gift
rules. The endpoint requires an existing read/write Commerce API owner with
store-management permissions.

Version 1.3.0 adds Loyalty Control: administrators can govern future earning
and redemption economics, pause either side of the program, set order limits,
preview outstanding reward liability, adjust an individual customer's balance,
send the existing branded notification and retain a complete policy and balance
audit trail. Existing customer balances, redemption history and awarded orders
remain untouched.

Version 1.4.0 adds the protected Order Operations and Inventory bridge. The
local suite can read and upload order evidence, manage product/lot COA
assignments, read the live restock program, and trigger eligible back-in-stock
notifications without exposing store credentials to the browser.

Version 1.5.0 adds idempotent packaging-evidence email delivery. The dashboard
sends the two confirmed images server-to-server; WordPress validates the order,
creates request-scoped temporary attachments, calls wp_mail() so the site's
existing SMTP plugin remains the transport owner, and removes the temporary
files immediately. Atomic locks and a bounded sent-event ledger prevent blind
duplicate delivery.

Version 1.6.0 adds idempotent fulfillment-to-order COA assignment. The
dashboard can mirror the exact vial lots confirmed during Packing into the
existing Order COA workspace. A stable event fingerprint and atomic WordPress
ledger make retries replay-safe while the dashboard still reconciles current
assignments before requesting any missing quantity.

Version 2.1.1 carries the immutable Packed confirmation through the protected
COA assignment request. The bridge rejects unconfirmed manual writes and only
forwards a physical-lot confirmation supplied by the authenticated dashboard.

Version 2.1.3 accepts the exact Available COA captured by the fulfillment
scanner as the authoritative physical lot. It validates the order item,
variation, SKU and quantity before saving a durable customer-order snapshot,
so certificates stored in the new Operations database no longer fail because
the legacy WordPress COA catalog does not contain the same record.

Version 2.1.4 gives packaging-evidence notifications one self-contained,
responsive email layout instead of nesting the message inside the active
WooCommerce theme. The logo has an explicit email-safe size, content remains
readable in light and dark mode, and the evidence photos remain attachments.

Version 2.2.0 adds product-level affiliate exclusions controlled from the
Operations Suite. Excluded products reject affiliate coupon discounts and are
marked on order lines so both the legacy plugin and the Phase One commission
ledger omit those products while preserving every other coupon rule.

Version 1.7.0 adds idempotent native shipment tracking save and void support.

Version 1.7.1 fixes inventory waitlist visibility. The bridge now reads active
subscriber records from both installed notifier families, preserves exact
product and variation relationships, and exposes the existing customer list to
the Operations Suite without sending notifications or changing stock.

Version 1.8.0 completes the native shipping lifecycle. Once postage and tracking
are confirmed, the bridge stores portable tracking metadata, sends the customer
a WooCommerce tracking note through the site's configured mail transport and
marks the order Completed. Replays remain idempotent, while voiding the same
label removes tracking and returns the order to Processing.

Version 1.9.0 lets the packing workflow continue with either one or two evidence
photos. WordPress validates every supplied image and sends exactly the available
evidence through the site's existing SMTP transport without weakening replay or
size protections.

Version 2.0.0 adds idempotent operational order repetition and administrator-only
customer recovery links. Repeated orders copy the exact products, quantities and
addresses into a zero-charge Processing order, remain visibly linked to the source
order and cannot inflate revenue. Recovery links use WordPress core one-use reset
keys, expire automatically and are never stored by the Operations Suite.

Version 2.0.1 sends customer recovery links to the public Phase One Labz password
portal instead of exposing the private WordPress staging login. The Operations Suite
also normalizes older bridge responses to the same public one-use reset experience.

Version 2.1.0 adds a protected, idempotent marketing-email transport. The Operations
Suite owns contacts, consent, templates and the durable delivery queue, while WordPress
continues to send through the SMTP plugin already configured on the site. No SMTP
password or provider secret is exposed to the dashboard.

